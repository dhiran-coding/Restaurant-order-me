// Demo JS
console.log('Restaurant demo loaded');