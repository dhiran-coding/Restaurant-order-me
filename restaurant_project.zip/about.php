<!doctype html>
<html>
<head><meta charset="utf-8"><title>About - My Restaurant</title><link rel="stylesheet" href="assets/css/style.css"></head>
<body>
  <h2>About Us</h2>
  <p>We serve fresh, tasty meals every day.</p>
  <a href="index.php">Back</a>
</body>
</html>
