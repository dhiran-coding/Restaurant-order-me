<!doctype html>
<html>
<head><meta charset="utf-8"><title>Book Table</title><link rel="stylesheet" href="assets/css/style.css"></head>
<body>
  <h2>Book a Table</h2>
  <form method="post" action="book_table.php">
    <label>Name: <input name="name" required></label><br>
    <label>Date & Time: <input name="datetime" type="datetime-local" required></label><br>
    <label>Guests: <input name="guests" type="number" min="1" value="2"></label><br>
    <button type="submit">Book</button>
  </form>
<?php
if($_SERVER['REQUEST_METHOD']==='POST'){
  $n = htmlspecialchars($_POST['name']);
  $dt = htmlspecialchars($_POST['datetime']);
  $g = (int)$_POST['guests'];
  echo "<p>Thanks $n — your table for $g on $dt is noted (demo).</p>";
}
?>
  <a href="index.php">Home</a>
</body>
</html>
