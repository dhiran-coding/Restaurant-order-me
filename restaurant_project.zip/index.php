<?php
// Simple index
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>My Restaurant</title>
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
  <header><h1>Welcome to My Restaurant</h1></header>
  <nav>
    <a href="index.php">Home</a> |
    <a href="about.php">About</a> |
    <a href="menu.php">Menu</a> |
    <a href="order.php">Order</a> |
    <a href="book_table.php">Book Table</a> |
    <a href="contact.php">Contact</a>
  </nav>
  <main>
    <p>Delicious food, cozy ambience.</p>
  </main>
  <script src="assets/js/main.js"></script>
</body>
</html>
