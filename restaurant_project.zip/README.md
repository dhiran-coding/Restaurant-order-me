# Restaurant Demo Project
This is a simple demo restaurant website structure with sample PHP pages and assets.

**Files**
- index.php, about.php, menu.php, order.php, book_table.php, contact.php
- assets/css/style.css
- assets/js/main.js
- admin/ (dashboard, add_item, view_orders, reservations)

**Usage**
- Place this folder inside your PHP-enabled web server document root (e.g., XAMPP htdocs).
- Start the server and open index.php in the browser.

This is a demo skeleton — adapt and secure it before using in production.
