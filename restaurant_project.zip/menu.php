<?php
$menu = [
  ['id'=>1,'name'=>'Margherita Pizza','price'=>299],
  ['id'=>2,'name'=>'Veg Burger','price'=>149],
  ['id'=>3,'name'=>'Pasta Alfredo','price'=>199],
];
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Menu</title><link rel="stylesheet" href="assets/css/style.css"></head>
<body>
  <h2>Menu</h2>
  <ul>
  <?php foreach($menu as $item): ?>
    <li><?php echo htmlspecialchars($item['name']); ?> — ₹<?php echo $item['price']; ?> 
      <a href="order.php?add=<?php echo $item['id']; ?>">Add</a>
    </li>
  <?php endforeach; ?>
  </ul>
  <a href="index.php">Home</a>
</body>
</html>
