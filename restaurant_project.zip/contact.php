<!doctype html>
<html>
<head><meta charset="utf-8"><title>Contact</title><link rel="stylesheet" href="assets/css/style.css"></head>
<body>
  <h2>Contact Us</h2>
  <p>Email: info@myrestaurant.example</p>
  <p>Phone: +91 98765 43210</p>
  <a href="index.php">Home</a>
</body>
</html>
