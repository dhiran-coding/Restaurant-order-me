<!doctype html>
<html>
<head><meta charset="utf-8"><title>Reservations</title><link rel="stylesheet" href="../assets/css/style.css"></head>
<body>
  <h2>Reservations (Demo)</h2>
  <p>This page would list reservations from the database in a real project.</p>
  <a href="dashboard.php">Back</a>
</body>
</html>
