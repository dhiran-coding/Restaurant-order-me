<?php
// Demo add item (no database)
if($_SERVER['REQUEST_METHOD']==='POST'){
  $name = htmlspecialchars($_POST['name']);
  $price = (float)$_POST['price'];
  $msg = "Added: $name — ₹$price (demo)";
}
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Add Item</title><link rel="stylesheet" href="../assets/css/style.css"></head>
<body>
  <h2>Add Menu Item</h2>
  <?php if(isset($msg)) echo "<p>$msg</p>"; ?>
  <form method="post">
    <label>Name: <input name="name" required></label><br>
    <label>Price: <input name="price" type="number" step="0.01" required></label><br>
    <button type="submit">Add</button>
  </form>
  <a href="dashboard.php">Back</a>
</body>
</html>
