<?php
// Simple admin demo (no auth)
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Admin Dashboard</title><link rel="stylesheet" href="../assets/css/style.css"></head>
<body>
  <h2>Admin Dashboard</h2>
  <ul>
    <li><a href="add_item.php">Add Item</a></li>
    <li><a href="view_orders.php">View Orders</a></li>
    <li><a href="reservations.php">Reservations</a></li>
  </ul>
</body>
</html>
