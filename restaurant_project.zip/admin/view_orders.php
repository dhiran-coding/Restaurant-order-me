<?php
// Demo showing session orders if any
session_start();
$menu_map = [1=>'Margherita Pizza',2=>'Veg Burger',3=>'Pasta Alfredo'];
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>View Orders</title><link rel="stylesheet" href="../assets/css/style.css"></head>
<body>
  <h2>Orders (Demo)</h2>
  <?php
  if(!empty($_SESSION['cart'])){
    echo "<ul>";
    foreach($_SESSION['cart'] as $id){
      echo "<li>".$menu_map[$id]."</li>";
    }
    echo "</ul>";
  } else {
    echo "<p>No orders (demo).</p>";
  }
  ?>
  <a href="dashboard.php">Back</a>
</body>
</html>
