<?php
session_start();
if(!isset($_SESSION['cart'])) $_SESSION['cart'] = [];
$menu_map = [
  1=>['name'=>'Margherita Pizza','price'=>299],
  2=>['name'=>'Veg Burger','price'=>149],
  3=>['name'=>'Pasta Alfredo','price'=>199],
];
if(isset($_GET['add'])){
  $id = (int)$_GET['add'];
  $_SESSION['cart'][] = $id;
  header('Location: order.php');
  exit;
}
$total = 0;
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Order</title><link rel="stylesheet" href="assets/css/style.css"></head>
<body>
  <h2>Your Order</h2>
  <ul>
  <?php foreach($_SESSION['cart'] as $id): 
    $item = $menu_map[$id];
    $total += $item['price'];
  ?>
    <li><?php echo $item['name']; ?> — ₹<?php echo $item['price']; ?></li>
  <?php endforeach; ?>
  </ul>
  <p>Total: ₹<?php echo $total; ?></p>
  <p>(This is a demo — no payment gateway included.)</p>
  <a href="menu.php">Add more</a> | <a href="index.php">Home</a>
</body>
</html>
